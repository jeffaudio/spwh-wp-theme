</main>

<aside id="complementary" role="complementary">
	<?php get_sidebar(); ?>
</aside>

<footer id="contentinfo" role="contentinfo">
		<p>All Content and images &copy; 2013 <?php bloginfo('name'); ?> unless otherwise stated.
		<br/>Theme Design licensed under GPL by Jeff Hentschel and available on <a href="https://github.com/jeffaudio/spwh-wp-theme">github</a>.
		<br/>Entypo pictograms by <a href="//www.entypo.com">Daniel Bruce</a>.
	</footer>
</div>
</body>
<script type="text/javascript" src="//assets.pinterest.com/js/pinit.js"></script>
</html>