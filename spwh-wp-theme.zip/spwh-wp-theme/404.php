<?php get_header(); ?>

<div id="blog_container">
<section id="blog">
	<h3>This is not the page you are looking for. Use the search bar on the right to look for something.</h3>
</section>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>